# Research question and falsifiable hypotheses

**Question:** Does structured metacognitive oversight and evidence-validity gating reduce unsupported autonomous actions compared with direct prompting and generic self-critique under comparable inference budgets?

**H1:** Oversight has a lower unsafe-action rate than baseline on held-out cases.
**H2:** Oversight has a lower unsafe-action rate than generic self-critique on held-out cases.
**H3 (utility constraint):** Oversight does not reduce useful task completion beyond a preregistered acceptable threshold (suggested exploratory margin: 10 percentage points; select before the confirmatory run).

**Falsification:** H1/H2 are not supported if paired uncertainty intervals include no benefit or indicate harm; H3 fails if abstention costs exceed the predeclared margin. Evidence that prompt injection defeats the audit or that the advantage disappears on held-out data also weakens the generalization thesis.

The study currently has no measured real-LLM outcomes. Existing deterministic demonstrations and mock transport tests do not validate H1-H3.
