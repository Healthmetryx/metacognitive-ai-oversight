# Anthropic Residency application — suggested portfolio description

**Metacognitive Oversight and Evidence-Validity Gating for Autonomous AI Agents**

Repository: `https://github.com/YOUR-USERNAME/metacognitive-ai-oversight`

I developed, with AI-assisted implementation support, a reproducible Python research prototype to investigate whether explicit evidence-validity and metacognitive oversight reduce unsupported decisions by autonomous language-model agents. The repository compares baseline, self-critique and structured oversight conditions on 48 matched synthetic scenarios, with equal call limits, an independent rule-based evaluator, automated tests and documented limitations. The software tests pass; live-model evaluation has not yet been conducted, and no empirical safety benefit is claimed. I am submitting the executable design as a starting point for rigorous empirical research in scalable oversight and AI control.
