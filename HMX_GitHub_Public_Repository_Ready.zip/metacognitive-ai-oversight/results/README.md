No live inference outputs are included. This directory is intentionally empty until a credentialed run is completed.
