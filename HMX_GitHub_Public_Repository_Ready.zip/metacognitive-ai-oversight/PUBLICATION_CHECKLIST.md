# Pre-publication checklist

- [ ] Confirm you have rights to publish all code and materials, including Healthmetryx-related intellectual property.
- [ ] Review AI-assisted authorship disclosure and confirm descriptions match your contributions.
- [ ] Check for secrets, personal information, private datasets and confidential partner details.
- [ ] Run tests locally and inspect outputs.
- [ ] Confirm `cases.json` is synthetic and contains no sensitive data.
- [ ] Decide whether to add an open-source license; none is included by default.
- [ ] Publish to a public GitHub repository and verify in a logged-out browser.
- [ ] Replace `YOUR-USERNAME` in application text with the actual GitHub account name.
- [ ] Paste the repository URL into the Anthropic application.
