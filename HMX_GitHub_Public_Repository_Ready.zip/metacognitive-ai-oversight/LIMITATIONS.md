# Evidence status and limitations

- **Verified:** Python harness, three prompted conditions, sealed scoring fields, reproducibility settings and mocked unit tests.
- **Not verified:** actual LLM behavior, empirical benefit, clinical or operational safety, transfer to other tasks, statistical significance.
- **Important:** the 75% / 50% / 0% figures belong to a separate deterministic toy simulation and must never be described as LLM findings.
- The baseline uses two independent direct decisions, whereas other arms use sequential revision; this is a fair call-budget comparison but not an identical information-flow comparison.
- Two calls and identical output caps do not guarantee matched actual input tokens, output tokens, latency or cost.
- The 48 cases are synthetic and designed around the validity policy; the evaluator is independent of agent outputs but not independently designed or human adjudicated.
- Mocked tests validate software behavior, not model accuracy or safety.
- No proprietary patient data, human subjects, or clinical decision-making is used.
- Provenance and evidence fields are synthetic assertions, not cryptographically verified external sources.
- Authors should review IP rights and remove proprietary code or confidential data before public release.
