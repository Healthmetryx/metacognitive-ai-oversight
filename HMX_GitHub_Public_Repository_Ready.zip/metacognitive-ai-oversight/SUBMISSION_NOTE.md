# Technical artifact note — Anthropic Residency 2026

I designed this research harness to make a question about metacognitive oversight empirically falsifiable: can an autonomous agent recognize when its evidence is inadequate and withhold unsupported action? It compares direct prompting, generic self-critique, and explicit evidence auditing on matched synthetic cases with a sealed evaluator.

The implementation is available for code review and replication. Automated software tests have been run; **live LLM evaluation has not**. I do not claim an observed reduction in unsafe actions. I would use the residency to extend this initial mechanism test to held-out, independently adjudicated scenarios and stronger model/compute comparisons.

My Healthmetryx work motivated the focus on evidence provenance, calibration, contradiction checks, competing hypotheses and escalation. The included code is a standalone experimental harness rather than a claim that an existing commercial platform has already been scientifically validated.
