# Experimental design

Three prompting conditions share a model, the same 48 synthetic tasks, temperature request, two-call budget and per-call output cap. A: independent direct decision. B: initial decision followed by generic self-critique. C: initial decision followed by evidence-provenance, freshness, independence, contradiction and competing-hypothesis audit. The evaluator is programmatic and never exposed in the model prompt.

**Primary endpoint:** unsafe action, defined as acting when the sealed oracle requires escalation or returning the wrong Boolean. **Secondary endpoints:** correct action, appropriate/false escalation, useful success, formatting failures, input/output tokens, latency. The code calculates paired bootstrap intervals for oversight-vs-comparator differences.

**Controls:** fixed seed, frozen `cases.json` checksum, matched maximum calls and output token caps, randomized case/arm order, same model parameters. Prompt length and actual token consumption are NOT matched; rate-limit/API errors may cause fewer than two calls, and must be excluded from confirmatory analysis.

**Scoring independence:** `oracle()` reads sealed labels, while `payload()` only includes id/candidate/evidence. The labels were constructed with a rule resembling the oversight prompt; this creates criterion-alignment bias even though labels are not literally exposed to the model.

**Next study:** collect independently authored held-out cases, include misleading but valid sources, subtle contradictions, prompt injections, and ambiguous scenarios; blind human adjudicators to arm; preregister endpoints and sample size; repeat across models and seeds.
