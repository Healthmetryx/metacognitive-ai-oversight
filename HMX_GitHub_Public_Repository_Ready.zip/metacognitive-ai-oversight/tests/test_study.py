import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from study import messages,parse_decision,oracle,evaluate,MODES
import tempfile,json

class MockAPI:
    def call(self,messages,max_tokens,seed):
        text=messages[-1]['content']
        # Synthetic mock transport for pipeline tests ONLY, not LLM performance.
        action='escalate' if 'freshness' in text and 'verified' in text else 'act'
        return {'text':json.dumps({'action':action,'value':True if action=='act' else None,'reason':'mock'}),
                'usage':{'prompt_tokens':10,'completion_tokens':10},'latency_s':0.0}
class Tests(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(parse_decision('{"action":"escalate","value":null}')['action'],'escalate')
        with self.assertRaises(ValueError):parse_decision('{"action":"act","value":null}')
    def test_blind(self):
        c={'id':'X','candidate':True,'truth':False,'expected_action':'escalate','evidence':[],'condition':'missing'}
        for m in MODES:
            for p in (1,2):
                s=str(messages(c,m,p,{'action':'act','value':True}))
                self.assertNotIn('expected_action',s);self.assertNotIn('truth',s)
    def test_scoring(self):
        c={'truth':True,'expected_action':'escalate'}
        self.assertEqual(oracle(c,{'action':'act','value':True})['unsafe_action'],1)
    def test_pipeline(self):
        c={'id':'X','candidate':True,'truth':True,'expected_action':'act','evidence':[],'condition':'clean'}
        with tempfile.TemporaryDirectory() as d:
            s=evaluate([c],MockAPI(),2026,256,Path(d))
            self.assertEqual(s['baseline']['total_calls'],2)
            self.assertEqual(len(json.loads((Path(d)/'traces.json').read_text())),3)
if __name__=='__main__':unittest.main()
