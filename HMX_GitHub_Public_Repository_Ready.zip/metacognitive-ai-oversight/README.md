# Metacognitive Oversight for Autonomous AI Agents

**An executable research prototype investigating evidence-validity gating, self-critique, and metacognitive oversight.**

[Research question](RESEARCH_QUESTION.md) · [Experimental design](EXPERIMENT_DESIGN.md) · [Limitations](LIMITATIONS.md) · [Reproduce](REPRODUCIBILITY.md) · [Researcher profile](RESEARCHER.md)

> **Research status:** The software has automated mock-transport tests. No live-model benchmark has been executed, and **no empirical LLM safety improvement is claimed**. This is a research prototype, not a production safety control.

## The question

Can an explicit evidence-validity and metacognitive oversight protocol reduce unsupported decisions by LLM-based agents, relative to baseline decision-making and conventional self-critique, without excessively reducing useful task completion?

## What is implemented

| Configuration | First pass | Second pass |
|---|---|---|
| A · Baseline | Direct initial decision | Independent direct final decision |
| B · Self-critique | Initial decision | Unstructured error review and revision |
| C · Oversight | Initial decision | Structured audit of provenance, source independence, freshness, contradictions and alternative hypotheses |

All three conditions receive the same synthetic cases, use the same configured model, and are capped at **two inference calls with equal maximum completion tokens per call**. Actual token consumption may differ and is recorded. A separate rule-based evaluator scores the resulting structured decisions against preassigned synthetic labels.

## Evaluation design

- **48 synthetic operational-status cases**, not clinical or real-world decisions.
- Preassigned scoring labels withheld from agent prompts by `payload()`.
- Outcomes include unsafe-action rate, appropriate escalation, false escalation, useful success, formatting failures, token use and latency.
- Paired bootstrap comparisons are generated only for complete runs.
- Cases and scoring criteria are published for inspection. This makes the suite **transparent, not a blind held-out benchmark**; generalization and potential benchmark overfitting remain open questions.

## Zero-cost verification

Python 3.10+; standard library only:

```bash
python -m unittest discover -s tests -v
```

## Optional live evaluation (requires user-provided API access)

The implementation targets an **OpenAI-compatible chat-completions endpoint**, not the native Anthropic Messages API. No live-model evaluation has been run.

```bash
export LLM_API_KEY='YOUR_KEY'  # set locally, never commit
export LLM_MODEL='YOUR_COMPATIBLE_MODEL'
python src/study.py --model "$LLM_MODEL" --limit 3 --out results/smoke
```

See [reproducibility](REPRODUCIBILITY.md) for full parameters. Avoid running a paid benchmark until you understand provider pricing.

## Where to look first

- [`src/study.py`](src/study.py) — prompts, transport, decision parsing, evaluator, metrics and bootstrap.
- [`tests/test_study.py`](tests/test_study.py) — software checks with mock responses.
- [`cases.json`](cases.json) — synthetic evaluation inputs and labels.
- [`EXPERIMENT_DESIGN.md`](EXPERIMENT_DESIGN.md) — experimental protocol and falsification criteria.
- [`LIMITATIONS.md`](LIMITATIONS.md) — threats to validity and scope of claims.

## Authorship, provenance and disclosure

Prepared as a reviewable research artifact for **Louis A. Young II**. The implementation was developed with AI assistance; the repository should not be interpreted as evidence of unaided individual authorship of every line. The applicant should review, understand and be able to explain the code and clearly describe their own contributions. No Healthmetryx patient data or credentials are included in the prepared package.

**Licensing:** No open-source license is granted at this stage. Public visibility is not permission to reuse; a license can be selected after an IP and ownership review.
