# Researcher profile — Louis A. Young II

**Technical founder and systems architect | Respiratory intelligence infrastructure | Empirical AI safety research applicant**

Louis A. Young II founded Healthmetryx, a respiratory intelligence infrastructure venture. His work has focused on systems architecture, data-driven decision support, evidence validation, and governance for high-stakes workflows. His prior professional background includes program and portfolio management at Leidos. He holds an MBA from Queen’s University Smith School of Business.

## Research direction

His proposed research investigates whether structured evidence validity checks and metacognitive oversight improve the reliability of autonomous AI agents. This repository operationalizes that question in three controlled LLM conditions and a reproducible synthetic evaluation protocol.

## What this repository demonstrates

- A falsifiable research question translated into runnable experimental software.
- A comparative protocol with matched cases and bounded model calls.
- Explicit evaluator criteria and limitations, including the absence of live-model findings.

## Attribution and research integrity

The project was assembled with AI assistance. Technical ownership and individual code contributions should be discussed accurately during review. This repository does not claim validated clinical performance, published research findings, or real-world safety guarantees.

## Contact

Use GitHub profile contact settings or the application contact information. No personal email address is published here.
