# Reproduction without paid inference

1. `python -m unittest discover -s tests -v` (mock API, no network, no fees).
2. Review `src/study.py`, `cases.json`, and sealed `expected_action`/`truth` fields.
3. For a real run, configure an authorized OpenAI-compatible chat-completions endpoint via `LLM_API_KEY`, `LLM_MODEL`, optionally `LLM_BASE_URL`. Never commit keys.
4. `python src/study.py --model "$LLM_MODEL" --limit 3 --out results/smoke` (18 requests).
5. `python src/study.py --model "$LLM_MODEL" --seed 2026 --max-tokens-per-call 256 --out results/live` (288 planned requests).
6. Verify all rows have `calls == 2` and no `error`; only then interpret paired comparisons.

Some models reject `seed`, `temperature`, or `max_tokens` parameters. Adapt the client consistently for all arms and document the change. This repository does not contain real-model result files.
